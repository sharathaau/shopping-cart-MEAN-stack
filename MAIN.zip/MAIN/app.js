var express = require("express");
var Mongo = require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/";
var path = require('path');
var app = express();

var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

// console.log(__dirname);
app.use(express.static('./client/view'));
app.use(express.static('./client'));
app.use(express.static('node_modules'));
//------------------------------------------------------------------------------------
// Linking to loginServices.js
var login = require('./server/loginServices.js');
app.use('/login', login);

//Linking to registrationServices.js
var registration = require('./server/registrationServices.js');
app.use('/validations', registration);

//Linking to address.js
var address = require('./server/address.js');
app.use('/address', address);

//Linking to cartServices.js
var cart = require('./server/cart/cartServices.js');
app.use('/cart', cart);

//linking to finalOrder.js
var finalOrder = require('./server/finalOrder.js');
app.use('/finalOrder', finalOrder);

//linking to productsServices.js
var products = require('./server/productsServices.js');
app.use('/products', products);

//linking to adminService.js
var admin = require('./server/adminService.js');
app.use('/admin', admin);




// ..................................................
app.listen(5000, function() {
    console.log("server running  @5000...." + Date());
});