// my address controller...................................................
myApp.controller('address', function($scope, $http, $rootScope) {

	$scope.user = JSON.parse(sessionStorage.loginDetails);
    $scope.myadd = function() {

        //$scope.user = JSON.parse(sessionStorage.loginDetails); 
		var ob = {
			email : $scope.user.userName
		};


        //alert("my addres!!!");
        var res = $rootScope.URL  + 'address' +  '/myadd';
        $http.post(res, ob).then(function(response) {

            $scope.cart = response.data;
            console.log('cart data',response.data);

        });

    }
        
    //default address change function
    $scope.default1 = function(d) {

        var ob2 = {
            default1: d,
			email : $scope.user.userName
        };

        //alert('default address change' + ob2.default1);
        var res = $rootScope.URL + 'address' + '/default';
        $http.post(res, ob2).then(function(response) {

            $scope.address = response.data;

        });

        //cart default

        // alert('default address change cart' + ob2.default1);
        var res = $rootScope.URL + 'address' + '/defaultCart1';
        $http.post(res, ob2).then(function(response) {

            $scope.addressCart = response.data;

            alert('orders', addressCart.deafault);

        });

    }
    //ng showHelp $scope.IsVisible = false;
    $scope.ShowHide = function() {
        //If DIV is visible it will be hidden and vice versa.
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }

    //add new address


    $scope.addnew = function() {
        // alert('add new');
        if ($scope.name == null || $scope.email == null || $scope.phnum == null || $scope.address == null) {
            alert("Please fill all the fields");
        }
        var temp = {
            name: $scope.name,
            email: $scope.email,
            phone: $scope.phnum,
            address: $scope.address
        };
        var res = $rootScope.URL + 'validations' + '/registrationPage';
        $http.post(res, temp).then(
            function(response) {

                if (response.data == 'true') {
                    alert("successfully added new address!!!");
                    window.location = $rootScope.URL + "#/myadd";
                }
                if (response.data == 'false') {
                    alert("invalid user..please enter correct credentials!!");
                }
            });

    }

    //add new address end
    //delete address
    $scope.deleteadd = function(p) {
        //alert('comming hey buddy' + p);
        var ob = {
            address: p
        };
        var res = $rootScope.URL + 'address' + '/deleteadd';
        $http.post(res, ob).then(
            function(response) {
                alert("successfully deleted address!!!");
                alert("successfully deleted address!!!");
                // window.location=$rootScope.URL+"#/mycart";

            });
        $scope.cart();

    }


    //delete adrdess end



});