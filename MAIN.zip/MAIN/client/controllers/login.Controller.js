// login controller
myApp.controller('login', function($scope, $http, $rootScope) {

    $scope.login = function() {
        if ($scope.username == null ||
            $scope.userpassword == null) {
            alert("please fill all the fields");
        }
        var temp = {
            userName: $scope.username,
            pass: $scope.userpassword
        };

        sessionStorage.loginDetails = "null";
        sessionStorage.loginDetails = JSON.stringify(temp);
        $scope.user = JSON.parse(sessionStorage.loginDetails);
        // $rootscope.user=$scope.user; 
        alert($scope.user.userName);




        var res = $rootScope.URL + 'login'+ '/loginPage';
        $http.post(res, temp).then(
            function(response) {

                if (response.data == 'true') {
                    alert("successfully logged in ..WELCOME!!!");
                    window.location = $rootScope.URL + "#/home";
                }
                if (response.data == 'false') {
                    alert("invalid user..please enter correct credentials!!");
                }
            });

    }

});