// cart controller...................................................
myApp.controller('cart', function($scope, $http, $rootScope) {

    $scope.cart = function() {

        // alert("successfully cart!!!");
        var res = $rootScope.URL + 'cart' + '/cart';
        $http.get(res).then(function(response) {

            $scope.cart = response.data;
            // console.log('cart data',response.data);

        });

    }



});






