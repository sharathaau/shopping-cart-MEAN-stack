
// admin controller

myApp.controller("admin", function($scope, $http) {

    $scope.sendData = function() {
        var myOb = {
            pname: $scope.pname,
            pimg: $scope.pimg,
            pcategory: $scope.pcategory,
            pprice: $scope.pprice
        };
        var res = $rootScope.URL + 'admin' + '/admin';
        $http.post(res, myOb).then(
            function(response) {

                if (response.data == 'true') {
                    //alert("successfully inserted in admin db!!!");
                    // window.location=$rootScope.URL+"#/display";
                }

            });
    }

});