//my oreders page_________________ 

myApp.controller('myorders', function($scope, $http, $rootScope) {

    //ng showHelp $scope.IsVisible = false;
    $scope.ShowHide = function() {
        //If DIV is visible it will be hidden and vice versa.
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }
    //calling cart function to load all the cart items
    $scope.cart = function() {
        // alert('my oredrs');

        $scope.user = JSON.parse(sessionStorage.loginDetails);
		var ob = {
			email : $scope.user.userName
		};
        var res = $rootScope.URL + 'cart' + '/mycart';
        $http.post(res, ob).then(function(response) {

            $scope.cart = response.data;
            //this has all the cart items  of sharathau8@gmail

        });
        var res = $rootScope.URL  + 'address' +  '/myadd';
        $http.post(res, ob).then(function(response) {

            $scope.address = response.data;
            //this has all the addresss of sharathau8@gmail
            //alert('orders',address.deafault);

        });



    }


    // choose function
    $scope.choose = function(p) {
        //alert(p);
        $rootScope.apid = p;

        $scope.myadd($scope.apid);



    }

    //calling address function inside myorders.html
    $scope.myadd = function(p) {
        // alert('calling myadd from click'+p);

        $scope.user = JSON.parse(sessionStorage.loginDetails);
		var ob = {
			email : $scope.user.userName
		};


        //alert("my addres!!!");
        var res = $rootScope.URL  + 'address' +  '/myadd';
        $http.post(res, ob).then(function(response) {

            $scope.add = response.data;
            // console.log('cart data',response.data);

        });

    }
    // update for pop-up addres in orders 

    $scope.updatepop = function(add) {
        // alert('hai'+add);
        //alert('apid'+ $rootScope.apid);
        //console.log(add + " " + itemId);
        var obj = {
            address: add,
            pid: $rootScope.apid
        };
        //alert(JSON.stringify(obj));
        var res = $rootScope.URL + 'address' +  '/oredersUpdate';
        $http.post(res, obj).then(function(response) {

        });

    }


    /* update addres in orders 

    $scope.update = function(add, itemId) {
        alert('hai'+add);
        console.log(add + " " + itemId);
        var obj = {
            address: add,
            pid: itemId
        };
        //alert(JSON.stringify(obj));
        var res = $rootScope.URL + 'oredersUpdate';
        $http.post(res, obj).then(function(response) {

        });

    }*/

    $scope.oneTime = function(itemId, add) {
        // alert('hai one time');
        console.log(add + " " + itemId);
        var obj = {
            address: add,
            pid: itemId
        };
        //alert(JSON.stringify(obj));
        var res = $rootScope.URL + 'address' +  '/oredersUpdateOne';
        $http.post(res, obj).then(function(response) {

        });

    }

    $scope.permanentAdd = function(itemId, add, email) {
        //alert('hai perm time');
        console.log(add + " " + itemId + " " + email);
        var obj = {
            address: add,
            pid: itemId,
            email: email
        };
        var res = $rootScope.URL + 'address' +  '/oredersUpdatePer';
        $http.post(res, obj).then(function(response) {

        });

    }
    //

    $scope.cid = 'p11';
    $scope.placeOrder = function(id) {
        alert('order placed successfully!!!!!!!!!!!');
        $scope.cid = id;
        console.log('cart dta', $scope.cid);
        // creating the object for cart
        // userid productid img pname qty price
		$scope.user = JSON.parse(sessionStorage.loginDetails);
		
		
        var obj = {
            email: $scope.user.userName,
            pid: $scope.cid.pid,
            img: $scope.cid.img,
            name: $scope.cid.name,
            price: $scope.cid.price,
            address: $scope.cid.address,
            status: "ordered",
            gift: "NO"

        };
        var res = $rootScope.URL + 'finalOrder' + '/f2';
        $http.post(res, obj).then(
            function(response) {

                if (response.data == 'true') {
                    //alert("successfully added to orders! Go to MyCart!!!");
                    // window.location=$rootScope.URL+"#/login";
                }

            });

    }
    // .....................................
    /* $scope.giftWrap = function(r) {

         alert("successfully Giftwrapped!!! " + r);

         var giftwraped = {
             pid: r,
             gift: true
         };
         var res = $rootScope.URL + 'giftWrap';
         $http.post(res, giftwraped).then(function(response) {
             alert(" Giftwrapped!!!");
             //window.location=$rootScope.URL+"#/mycart";

         });
         //$scope.cart();

     } */
    //



});