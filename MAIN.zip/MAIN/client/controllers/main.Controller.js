// all controllers logic starts from here
myApp.controller('mainController', function($scope) {

    $scope.message = 'Everyone come and see how good I look!';

});
// display controller...................................................
myApp.controller('main', function($scope, $http, $rootScope) {

    //this i the global url for every request from client top server ,just change here
    $rootScope.URL = "http://localhost:5000/";
    //alert($rootScope.URL);

    $scope.x = 'name';
    $scope.cart = function(name) {
        $scope.x = name;
        var myOb = {
            name: $scope.x
        };
        var res = $rootScope.URL + 'products' + '/displaycat1';
        $http.post(res, myOb).then(
            function(response) {
                $scope.cart1 = response.data;

                window.location = $rootScope.URL + "#/display";
            });

    }

    // display rootscope controller
    $rootScope.cart2 = {};
    $scope.pid = 'p11';
    $scope.PD = function(id) {
        $scope.pid = id;
        console.log('cart root data', $scope.pid);
        var pid = {
            pid: $scope.pid
        };
        var res = $rootScope.URL + 'products' + '/PD';
        $http.post(res, pid).then(function(response) {

            $rootScope.cart2 = response.data;
            // alert(JSON.stringify($rootScope.cart2));

            console.log('cart root data', $rootScope.cart2);
            window.location = $rootScope.URL + "#/product_details";
        });

    }

    // add to cart.............
    
    
    
    //-----------------
     $scope.myaddMain = function() {
         alert('vvvvvvvvvvvvvvvvvvvvv');

        $scope.user = JSON.parse(sessionStorage.loginDetails); 
		var ob = {
			email : $scope.user.userName
		};


        //alert("my addres!!!");
        var res = $rootScope.URL  + 'address' +  '/myaddMain';
        $http.post(res, ob).then(function(response) {

            $scope.myaddMain = response.data;
            console.log('cart len myaddMain',$scope.myaddMain);
            console.log('cart len myaddMain',$scope.myaddMain.deafault);
          
        });

    }
    //-----------------
    $scope.cid = 'p11';
    $scope.addtocart = function(id,y) {
        $scope.myaddMain();
        $scope.cid = id;
        console.log('cart dta', $scope.cid);
        // creating the object for cart
        $scope.cyid = y;
        console.log('cart dta default', $scope.cyid);
        // userid productid img pname qty price
    
        $scope.user = JSON.parse(sessionStorage.loginDetails); 
				
        var obj = {
            email: $scope.user.userName,
            pid: $scope.cid.pid,
            img: $scope.cid.pimage,
            name: $scope.cid.pname,
            price: $scope.cid.pprice,
            address: "mysore"
        };
        var res = $rootScope.URL + 'cart' + '/addtocart';
        $http.post(res, obj).then(
            function(response) {

                if (response.data == 'true') {
                    alert("successfully added to cart! Go to MyCart!!!");
                    // window.location=$rootScope.URL+"#/login";
                }

            });

    }
    // .....................................

});
