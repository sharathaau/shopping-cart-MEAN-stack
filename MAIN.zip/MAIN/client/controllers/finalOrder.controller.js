// final orders
myApp.controller('finalOrder', function($scope, $http, $rootScope) {


    $scope.ShowHide = function() {
        //If DIV is visible it will be hidden and vice versa.
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }

    $scope.cart = function() {
        //alert('my oredrs');

        $scope.user = JSON.parse(sessionStorage.loginDetails); 
		var ob = {
			email : $scope.user.userName
		};
        var res = $rootScope.URL + 'finalOrder' + '/finalorder';
        $http.post(res, ob).then(function(response) {

            $scope.orders = response.data;
            console.log('data in orders is...', $scope.orders);


        });

        var res = $rootScope.URL  + 'address' +  '/myadd';
        $http.post(res, ob).then(function(response) {

            $scope.address = response.data;
            console.log('data in orders is...', $scope.address);
            //this has all the addresss of sharathau8@gmail
            // alert('orders////////////');

        });

    }

    /*
     $scope.cart = function() {
       // alert('my oredrs');

        var ob = {
            email: 'sharathau8@gmail.com'
        };
        var res = $rootScope.URL + 'mycart';
        $http.post(res, ob).then(function(response) {

            $scope.cart = response.data;
            //this has all the cart items  of sharathau8@gmail

        });
        var res = $rootScope.URL + 'myadd';
        $http.post(res, ob).then(function(response) {

            $scope.address = response.data;
            //this has all the addresss of sharathau8@gmail
            //alert('orders',address.deafault);

        });



    }
    */
    //edit product and edit address
    $scope.cancel = function(p, q) {
        // alert('status is...' + p +q)

        if (p == "delivered") {
            alert("Cannot be changed. Item is delivered");
        } else if (p == "shipped") {
            alert("Cannot be changed. Item is shipped");
        } else if (p == "packed") {
            alert("Cannot be changed. Item is packed");
        } else {
            //alert("your product widd be removed from orders", +q);

            // delete item.......
            var ob = {
                pid: q
            };
            var res = $rootScope.URL + 'finalOrder' + '/deleteitemOrder';
            $http.post(res, ob).then(
                function(response) {
                    alert("successfully deleted from orders!!!");
                    // window.location=$rootScope.URL+"#/mycart";

                });
            $scope.cart();




        }

    }



  
    // gift wrap 
    $scope.giftWrap = function(r) {


        var giftwraped = {
            pid: r,
            gift: "YES"
        };
        var res = $rootScope.URL + 'finalOrder' + '/giftWrap';
        $http.post(res, giftwraped).then(function(response) {
            alert(" Giftwrapped!!!");
            //window.location=$rootScope.URL+"#/mycart";

        });
        //$scope.cart();

    }


    // choose function
    $scope.chooseFinal = function(status,p) {
        //alert('mmmmmmmmmm'+p);
        $rootScope.fpid = p;

        //$scope.myadd($scope.apid);



    }

    
      $scope.editaddress = function(status,pid) {
          $rootScope.fpid=pid;
       // alert("address staus is..." + status);
          //  alert("address pid is..." + pid);
        if (status== "delivered") {
            alert("Cannot be changed. Item is delivered....!!!!");
        } else {
          $scope.updatepopFinal(pid);
            
            $scope.ShowHide();
            $scope.ShowHide = function() {
     
                this.IsVisible =true;
    }

        
        }


    }
    // update for pop-up addres in orders 

    $scope.updatepopFinal = function(add) {
         //alert('updatefinal'+ $rootScope.fpid +"  "+ add);
        
        

        var obj = {
            address: add,
            pid: $rootScope.fpid
        };
        //alert(JSON.stringify(obj));
        var res = $rootScope.URL  + 'address' +  '/oredersUpdateFinal';
        $http.post(res, obj).then(function(response) {

        });

    }
    
    //status tracking
    
$scope.check=function(orderItem)
    {
        var p = orderItem.status;
        var q = orderItem.pid;
    //alert("status"+p);
    var pid;
   // alert(q);

    if(p=="ordered")
        {
        orderItem.trackstatus = "Ordered";
        orderItem.aks="25";
        orderItem.color="progress-bar-danger";
        }
        else if(p=="packed")
        {
        orderItem.trackstatus = "Packed";
        orderItem.aks="50";
        orderItem.color="progress-bar-info";

        }
        else if(p=="shipped")
        {
            
        orderItem.trackstatus = "Shipped";
        orderItem.aks="75";
        orderItem.color="progress-bar-warning";
        }
        else
        {
        
        orderItem.trackstatus = "Delivered";
        orderItem.aks="100";
        orderItem.color="progress-bar-success";
        }
    }





});


       