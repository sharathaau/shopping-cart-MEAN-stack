
// my cart controller...................................................
myApp.controller('mycart', function($scope, $http, $rootScope) {

    $scope.cart = function() {

        $scope.user = JSON.parse(sessionStorage.loginDetails);
		var ob = {
			email : $scope.user.userName
		};
        var res = $rootScope.URL + 'cart' + '/mycart';
        $http.post(res, ob).then(function(response) {

            $scope.cart = response.data;

        });

    }


    // delete item.......

    $scope.deleteitem = function(p) {
        var ob = {
            pid: p
        };
        var res = $rootScope.URL + 'cart' + '/deleteitem';
        $http.post(res, ob).then(
            function(response) {
                alert("successfully deleted!!!");
                // window.location=$rootScope.URL+"#/mycart";

            });
        $scope.cart();

    }

});