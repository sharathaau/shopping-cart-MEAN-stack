// register controller
myApp.controller("registration", function($scope, $http, $rootScope) {

    var add1 = new Array;
    $scope.sendData = function() {
        var myOb = {
            gender: $scope.gender,
            name: $scope.name,
            lname: $scope.lname,
            email: $scope.email,
            pass: $scope.pass,
            cpass: $scope.cpass,
            date: $scope.date,
            comp: $scope.comp,
            address: $scope.add1,
            deafault: $scope.add2,
            phone: $scope.phone


        };
        var res = $rootScope.URL + 'validations'+'/validationsPage';
        $http.post(res, myOb).then(function(response) {

            if (response.data == 0) {
                var res1 = $rootScope.URL + 'validations' + '/registrationPage';
				$http.post(res1, myOb).then(function(response) {
					if (response.data == 'true') {
						alert("successfully registerd!!!");
						//window.location = "http://localhost:3000/#/login";
						window.location=$rootScope.URL+"#/login";
					}
				});
			}
			else{
				
				alert("You have an account. You can Login !!!");			
				//window.location = "http://localhost:3000/#/login";
				window.location=$rootScope.URL+"#/login";
			}
			

        }); 
		
		
		
		
    }

});