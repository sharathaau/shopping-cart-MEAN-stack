var myApp = angular.module('myApp', ['ngRoute']);
//global url
//angular.module('myApp').constant('URL', 'http://192.168.10.55:3000/');

// configure our routes
myApp.config(function($routeProvider) {
    $routeProvider

        // route for the home page
        .when('/', {
            templateUrl: 'pages/featured.html',
            controller: 'main'

        }).when('/home', {
            templateUrl: 'pages/featured.html',
            controller: 'mainController'
        })
    
        .when('/listView', {
            templateUrl: 'pages/listView.html',
            controller: 'display'
        })

        .when('/tents', {
            templateUrl: 'pages/tents.html',
            controller: 'aboutController'
        
        }).when('/blockView', {
            templateUrl: 'pages/blockView.html',
            controller: 'aboutController'
        
        }).when('/bag_details', {
            templateUrl: 'pages/bag_details.html',
            controller: 'aboutController'
        })

        .when('/myCarousel', {
            templateUrl: 'pages/bag1.html',
            controller: 'aboutController'
        
        }).when('/login', {
            templateUrl: 'pages/login.html',
            controller: 'login'
        
        }).when('/register', {
            templateUrl: 'pages/register.html',
            controller: 'registration'
        
        })

        .when('/cart', {
            templateUrl: 'pages/cart.html',
            controller: 'cart'
        })

        .when('/admin', {
            templateUrl: 'pages/admin.html',
            controller: 'cart'
        })

        .when('/display', {
            templateUrl: 'pages/display.html',
            controller: 'main'
        
        }).when('/product_details', {
            templateUrl: 'pages/product_details.html',
            controller: ''
        })

        .when('/mycart', {
            templateUrl: 'pages/mycart.html',
            controller: 'mycart'
        })

        .when('/myadd', {
            templateUrl: 'pages/myAddress.html',
            controller: 'address'
        })

        .when('/myorders', {
            templateUrl: 'pages/myorders.html',
            controller: 'myorders'
        })

        .when('/finalorder', {
            templateUrl: 'pages/finalorder.html',
            controller: 'finalOrder'
        })
    
        .when('/track', {
            templateUrl: 'pages/finalorder.html',
            controller: 'finalOrder'
        })
    
        .when('/payment', {
            templateUrl: 'pages/payment.html',
            controller: 'payment'
        })
  

});