var mongoose = require('mongoose'),
    Schema = mongoose.Schema;
var ordersSchema = new Schema({	
	email: String,
 pid: String, 
 img: String,
 name: String,
 price:String,
 address: String, 
 status:String,
 gift: String,
 
}, { collection: 'orders' });

mongoose.model('orders', ordersSchema);




