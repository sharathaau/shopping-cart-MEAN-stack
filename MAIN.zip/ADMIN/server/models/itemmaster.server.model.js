﻿var mongoose = require('mongoose'),
    Schema = mongoose.Schema;
var ItemMasterSchema = new Schema({	
	pimage: String,
 pname: String, 
 pid: String,
 pcategory: String,
 ptype:String,
 pdesc: String, 
 pprice:String,
 pbrand: String,
 pcolour: String,
 psize: String,
 pdimen: String, 
 pguide: String,
 ptech:[],  
}, { collection: 'category1' });

mongoose.model('ItemMaster', ItemMasterSchema);




