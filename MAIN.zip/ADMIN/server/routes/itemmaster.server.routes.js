﻿
module.exports = function (app) {
    // Product master routes
    app.route('/api/updateItemMaster').put(Masters.itemupdate);
    app.route('/api/AddItemMaster').post(Masters.createitem);
    app.route('/api/masteritemlist').get(Masters.itemlist);
}

