﻿var Masters = require('../models/itemmaster.server.model'),
     passport = require('passport');
	 
var mongoose = require('mongoose'),
Item = mongoose.model('ItemMaster');


//saving the data to category1 db

exports.createitem = function (req, res, next) {
	console.log('reching server hai.................',req.body);

    var item = new Item(req.body);
    item.save(function (err, response) {
        if (err) {
            res.send({ success: false, msg: 'Failed to save', response: err });
        } else {
            res.json({ success: true, msg: 'Saved Successfully', result: response });
        }
    });
};

//updating the data of category 1 for more specifications

exports.itemupdate = function (req, res, next) {
	//console.log(req.body);
	var temp = req.body;
	var datatopush={key:temp.key,value:temp.value};
    Item.updateOne({pid:temp.pid},{$push:{ptech:datatopush}}, function (err, result) {
        if (err) {
	     res.send({ success: false, msg: 'Failed To Update', response: err });
        } else {
			 //console.log('success');
            // console.log(result);
            res.json({ success: true, msg: 'Updated Successfully', item: result });
        }
    });
};

//displaying the data from category1 db

exports.itemlist = function (req, res, next) {
	console.log('hai');
    Item.find({}, function(err, data) {
	if (err) {
            res.send({ success: false, msg: 'failed to delete', response: err });
        }
	res.send(data);
		});
	}



//for deleting Item Master

exports.partydelete = function (req, res, next) {
    console.log('coming to delete');
	var myquery = req.body;
    Item.deleteOne({pid:myquery.pid}, function (err, response) {

        if (err) {
            res.send({ success: false, msg: 'failed to delete', response: err });
        } else {
            res.send({ success: true, msg: 'Deleted Successfully', result: response });

        }
    })

}