var Masters = require('../models/orders.server.model'),
     passport = require('passport');
	 
var mongoose = require('mongoose'),
Item = mongoose.model('orders');

//displaying the data from category1 db

exports.orders = function (req, res, next) {
	//console.log('hai orders');
    Item.find({}, function(err, data) {
	if (err) {
	res.send("error");
	return;
				}
		res.send(data);
		});
	}
//updating the data of category 1 for more specifications

exports.ordersupdate = function (req, res, next) {
	//console.log(req.body);
var myOb = req.body;
	
    Item.updateOne({pid:myOb.pid}, {$set: {status: myOb.status}}, function (err, result) {
        if (err) {
	     res.send({ success: false, msg: 'Failed To Update', response: err });
        } else {
			 console.log('success');
             //console.log(result);
            res.json({ success: true, msg: 'Updated Successfully', item: result });
        }
    });
};

