var express = require("express");
var path = require('path');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('node_modules'));


app.use(express.static('./client'));


//mongoose database........................................................
var mongoose = require('mongoose');
var connection = require("./server/config/db");

//routers are written inside server file need to put it ina separate folder 
//category 1 
var Masters = require('./server/controllers/itemmaster.server.controller'),passport = require('passport');
app.route('/api/AddItemMaster').post(Masters.createitem);
app.route('/api/updateItemMaster').post(Masters.itemupdate);   
app.route('/api/masteritemlist').get(Masters.itemlist);
app.route('/api/delete').post(Masters.partydelete); 

//orders
var Masters1 = require('./server/controllers/orders.server.controller'),passport = require('passport');
app.route('/api/ordersDisplay').get(Masters1.orders); 
app.route('/api/ordersupdate').post(Masters1.ordersupdate);  




//..................................................
app.listen(3000,function(){
    console.log("server running  @3000....");
});
