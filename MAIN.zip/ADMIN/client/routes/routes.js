// create the module and name it myApp
// also include ngRoute for all our routing needs
var myApp = angular.module('myApp', ['ngRoute']);

// configure our routes
myApp.config(function ($routeProvider) {
    $routeProvider

        // route for the home page
        .when('/', {
            templateUrl: 'view/display.html',
            controller: 'display'
        })
    

       
        .when('/logistics', {
            templateUrl: 'view/logistics.html',
            controller: 'logistic'
        })


   
        .when('/category1', {
            templateUrl: 'view/category1.html',
            controller: 'admin'
        })
		.when('/category1', {
            templateUrl: 'view/category1.html',
            controller: 'morespec'
        })

        .when('/display', {
            templateUrl: 'view/display.html',
            controller: 'display'
        })      
});