
//add more specification
myApp.controller("morespec", function ($scope, $http) {



    $scope.updatedata= function (a,b,c) {
	//var key=$scope.key
		alert("update data"+a +"  "+b+" "+c);
		//alert("reaching");
        var myOb ={key:a,value:b,pid:c};
		alert(JSON.stringify(myOb));
        $http.post("http://localhost:3000/api/updateItemMaster", myOb).then(function (response) {

            if (response.data == 'true') {
                //alert("key value"+$scope.value);
                //window.location = "http://localhost:3000/#/display";
            }

        });
    }
});


