myApp.controller("admin", function ($scope, $http) {



    $scope.sendData = function () {
		alert('cmg');
        var myOb = { pimage: $scope.pimage, pname: $scope.pname, pid: $scope.pid, pcategory: $scope.pcategory, ptype: $scope.ptype, pdesc: $scope.pdesc, pprice: $scope.pprice, pbrand: $scope.pbrand, pcolour: $scope.pcolour, psize: $scope.psize, pdimen: $scope.pdimen, pguide: $scope.pguide, ptech:[]};
        $http.post("http://localhost:3000/api/AddItemMaster", myOb).then(function (response) {

            if (response.data == 'true') {
                alert("successfully inserted in category1 db!!!");
            }

        });
    }

});

