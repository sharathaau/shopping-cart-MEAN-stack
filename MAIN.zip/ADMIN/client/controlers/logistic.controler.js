//logistics controller...................................................
myApp.controller('logistic', function ($scope, $http) {

    $scope.status = ["ordered","packed","shipped","delivered"];

    $scope.logis = function () {


        $http.get("http://localhost:3000/api/ordersDisplay").then(function (response) {
             //alert("successfully cart 7777!!!");
            $scope.log = response.data;
            
        });

    }

    $scope.update = function (pstatus,itemId) {
      //  alert(status+" "+itemId);

        var obj = { status: pstatus, 
            pid:itemId };
        //alert(JSON.stringify(obj));
        $http.post("http://localhost:3000/api/ordersupdate", obj).then(function (response) {
            $scope.log(); 
        });

    }

    $scope.editproduct = function (status) {

        if(status=="delivered"){
            alert("Cannot be changed. Item is delivered");
        }
        else if(status=="shipped"){
            alert("Cannot be changed. Item is shipped");
        }
        else if (status=="packed"){
            alert("Cannot be changed. Item is packed");
        }
        else {
            window.open('https://www.google.co.in/');
        }
       
    }



$scope.editaddress = function (status) {

    if(status=="delivered"){
        alert("Cannot be changed. Item is delivered");
    }
   
    else {
        window.open('https://www.google.co.in/');
    }


}
});
