
//display controller display category1 items...................................................
myApp.controller('display', function ($scope, $http) {


    $scope.cart = function () {


        $http.get("http://localhost:3000/api/masteritemlist").then(function (response) {
            console.log("successfully cart 7777!!!",response.data);
            $scope.cart1 = response.data;
            
        });

    }
    //deleteRow
      $scope.deleteUser = function (p) {
       // var index = $scope.cart1.indexOf(p);
        var ob = { pid: p.pid };
        $http.post("http://localhost:3000/api/delete",ob).then(function (response) {
            $scope.cart(); 
        });

    }


});